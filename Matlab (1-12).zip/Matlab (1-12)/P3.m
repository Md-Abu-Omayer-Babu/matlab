n = -3:3;
x = [2 3 1 0 1 3 2];

xe = (x + fliplr(x)) / 2;   % even part
xo = (x - fliplr(x)) / 2;   % odd part

subplot(3,1,1), stem(n,x),  title('Original')
subplot(3,1,2), stem(n,xe), title('Even part')
subplot(3,1,3), stem(n,xo), title('Odd part')