t = 0:0.001:1;
x = sin(2*pi*5*t);

bits = [2 4 8];

for i = 1:3
    L = 2^bits(i);              % levels
    xq = round(x*(L/2))/(L/2);  % quantization

    e = x - xq;                % error
    mse = mean(e.^2);

    subplot(3,2,2*i-1)
    plot(t,xq)
    title([num2str(bits(i)) ' bit signal'])

    subplot(3,2,2*i)
    plot(t,e)
    title(['Error, MSE=' num2str(mse)])
end