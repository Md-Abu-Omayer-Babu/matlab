n = 0:3;
x = [1 2 3 4];

% Time shifting
x_shift = [0 0 x];        % shift right by 2

% Scaling
x_scale = 2 * x;

% Reversal
x_rev = fliplr(x);

% Plot
subplot(2,2,1), stem(x), title('Original')
subplot(2,2,2), stem(x_shift), title('Shifted')
subplot(2,2,3), stem(x_scale), title('Scaled')
subplot(2,2,4), stem(x_rev), title('Reversed')