t = 0:0.001:1;          % "analog" signal (very fine)
f = 5;                  % signal frequency (5 Hz)

x = sin(2*pi*f*t);     % original signal

% Sampling rates
fs1 = 2*f;             % Nyquist
fs2 = 4*f;             % Above Nyquist
fs3 = 1.5*f;           % Below Nyquist

t1 = 0:1/fs1:1;
t2 = 0:1/fs2:1;
t3 = 0:1/fs3:1;

x1 = sin(2*pi*f*t1);
x2 = sin(2*pi*f*t2);
x3 = sin(2*pi*f*t3);

subplot(4,1,1), plot(t,x), title('Original Signal')
subplot(4,1,2), stem(t1,x1), title('Nyquist')
subplot(4,1,3), stem(t2,x2), title('Above Nyquist')
subplot(4,1,4), stem(t3,x3), title('Below Nyquist')