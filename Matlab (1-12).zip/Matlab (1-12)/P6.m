t = 0:0.001:1;
f = 5;

x = sin(2*pi*f*t);

% Sampling
fs = 10;
ts = 0:1/fs:1;
xs = sin(2*pi*f*ts);

% Reconstruction (interpolation)
xr = interp1(ts, xs, t, 'linear');

% Plot
subplot(2,1,1)
plot(t, x), hold on
stem(ts, xs)
title('Original + Samples')

subplot(2,1,2)
plot(t, xr)
title('Reconstructed Signal')