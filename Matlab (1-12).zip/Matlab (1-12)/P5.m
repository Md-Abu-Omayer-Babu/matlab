t = 0:0.001:1;
f = 10;

x = sin(2*pi*f*t);

% Sampling rates
fs1 = 2*f;    % Nyquist
fs2 = 25;     % Above Nyquist
fs3 = 15;     % Below Nyquist (aliasing case)

t1 = 0:1/fs1:1;
t2 = 0:1/fs2:1;
t3 = 0:1/fs3:1;

x1 = sin(2*pi*f*t1);
x2 = sin(2*pi*f*t2);
x3 = sin(2*pi*f*t3);

subplot(4,1,1), plot(t,x), title('Original Signal')
subplot(4,1,2), stem(t1,x1), title('Nyquist')
subplot(4,1,3), stem(t2,x2), title('Above Nyquist')
subplot(4,1,4), stem(t3,x3), title('Aliasing (Below Nyquist)')