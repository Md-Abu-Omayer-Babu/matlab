t = 0:0.001:1;

% Composite signal
x = sin(2*pi*5*t) + sin(2*pi*20*t);

% FFT
X = fft(x);
N = length(X);

f = (0:N-1)*(1/(t(end)-t(1)))/N;

% Magnitude spectrum
mag = abs(X);

plot(f, mag)
title('Frequency Spectrum')
xlabel('Frequency (Hz)')