t = 0:0.001:1;
x = sin(2*pi*5*t);

L = 8;                  % number of levels
xq = round(x*(L/2))/(L/2);

subplot(2,1,1)
plot(t,x)
title('Original Signal')

subplot(2,1,2)
plot(t,xq)
title('Quantized Signal')