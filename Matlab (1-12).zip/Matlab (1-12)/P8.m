t = 0:0.001:1;
x = sin(2*pi*5*t);

L = 8;

% Quantization
xq = round(x*(L/2))/(L/2);

% Error
e = x - xq;

% MSE
mse = mean(e.^2);

% Plot
subplot(3,1,1)
plot(t,x), title('Original')

subplot(3,1,2)
plot(t,xq), title('Quantized')

subplot(3,1,3)
plot(t,e), title('Error Signal')

disp(mse)