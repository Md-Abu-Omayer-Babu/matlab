n = -10:10;

u = n >= 0;        % step
d = (n == 0);      % impulse
r = n .* (n >= 0); % ramp
s = sin(n);        % sine
c = cos(n);        % cosine

subplot(3,2,1), stem(n,u), title('Step')
subplot(3,2,2), stem(n,d), title('Impulse')
subplot(3,2,3), stem(n,r), title('Ramp')
subplot(3,2,4), plot(n,s), title('Sine')
subplot(3,2,5), plot(n,c), title('Cosine')