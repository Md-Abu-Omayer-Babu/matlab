% Problem 8: Quantization Error Analysis

t = 0:0.001:1;
x = sin(2*pi*5*t);

L = 8;
xq = round(x*(L/2-0.5))/(L/2-0.5);  % quantization

e = x - xq;                % error
mse = mean(e.^2);          % MSE

subplot(3,1,1); plot(t,x); title('Original'); xlabel('t');
subplot(3,1,2); plot(t,xq); title('Quantized'); xlabel('t');
subplot(3,1,3); plot(t,e); title(['Error, MSE=' num2str(mse)]); xlabel('t');
