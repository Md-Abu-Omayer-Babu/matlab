% Problem 6: Reconstruction

t = 0:0.001:1;
f = 5;
x = sin(2*pi*f*t);

fs = 10;
ts = 0:1/fs:1;
xs = sin(2*pi*f*ts);

xr_linear = interp1(ts,xs,t,'linear');
xr_spline = interp1(ts,xs,t,'spline');

subplot(4,1,1); plot(t,x); title('Original'); xlabel('t');
subplot(4,1,2); stem(ts,xs); title('Samples'); xlabel('t');
subplot(4,1,3); plot(t,xr_linear); title('Linear Interpolation'); xlabel('t');
subplot(4,1,4); plot(t,xr_spline); title('Spline Interpolation'); xlabel('t');
