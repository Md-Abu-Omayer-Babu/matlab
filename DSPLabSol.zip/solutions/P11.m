% Problem 11: Frequency Spectrum Analysis

t = 0:0.001:1;
fs = 1000;

% Composite signal (5Hz + 20Hz)
x = sin(2*pi*5*t) + sin(2*pi*20*t);

N = length(x);
X = fftshift(fft(x));
f = linspace(-fs/2, fs/2, N);

subplot(2,1,1); plot(t,x); title('Signal (5Hz + 20Hz)'); xlabel('t');
subplot(2,1,2); plot(f,abs(X)); title('Centered Frequency Spectrum'); xlabel('Frequency (Hz)');
