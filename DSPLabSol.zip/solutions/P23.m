% Problem 23: Aliasing + Filtering Combined

fs = 1000;
t = 0:1/fs:1;
f = 50;

% Original signal
x = sin(2*pi*f*t);

% Sample below Nyquist (aliasing)
fs_alias = 75;
ts = 0:1/fs_alias:1;
x_alias = sin(2*pi*f*ts);

% Anti-aliasing filter (low-pass before sampling)
fc = fs_alias/2;
b = fir1(20, fc/(fs/2));
x_filtered = filter(b, 1, x);

subplot(3,1,1); plot(t,x); title('Original Signal'); xlabel('t');
subplot(3,1,2); stem(ts,x_alias); title('Aliased (no filter)'); xlabel('t');
subplot(3,1,3); plot(t,x_filtered); title('After Anti-aliasing Filter'); xlabel('t');
