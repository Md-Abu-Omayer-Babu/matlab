% Problem 3: Even and Odd Decomposition

n = -3:3;
x = [2 3 1 0 1 3 2];

xe = (x + fliplr(x)) / 2;   % even part
xo = (x - fliplr(x)) / 2;   % odd part

verify = xe + xo;           % verification

subplot(4,1,1); stem(n,x);  title('Original'); xlabel('n');
subplot(4,1,2); stem(n,xe); title('Even part'); xlabel('n');
subplot(4,1,3); stem(n,xo); title('Odd part'); xlabel('n');
subplot(4,1,4); stem(n,verify); title('Verification: xe + xo'); xlabel('n');
