% Problem 13: Statistical Measures

x = [4 8 6 5 3 2 7 9 1 5];

m = mean(x);
v = var(x);
sd = std(x);
sk = skewness(x);
kt = kurtosis(x);

disp(['Mean: ' num2str(m)]);
disp(['Variance: ' num2str(v)]);
disp(['Std Dev: ' num2str(sd)]);
disp(['Skewness: ' num2str(sk)]);
disp(['Kurtosis: ' num2str(kt)]);
