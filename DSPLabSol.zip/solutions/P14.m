% Problem 14: Correlation & Covariance

x = [1 2 3 4 5];
y = [2 4 5 4 5];

% Auto-correlation
[acf, lags] = xcorr(x, 'coeff');

% Cross-correlation
[ccf, lags2] = xcorr(x, y, 'coeff');

% Covariance
cv = cov(x, y);

figure;
subplot(3,1,1); stem(lags, acf); title('Auto-correlation of x');
subplot(3,1,2); stem(lags2, ccf); title('Cross-correlation of x and y');
subplot(3,1,3); bar(cv); title('Covariance Matrix');

disp('Covariance Matrix:'); disp(cv);
