% Problem 12: Short-Time Fourier Transform (STFT)

fs = 1000;
t = 0:1/fs:1;

% Stationary signal (constant frequency)
x1 = sin(2*pi*50*t);

% Non-stationary signal (changing frequency)
x2 = sin(2*pi*(20*t + 100*t.^2));

subplot(2,1,1); spectrogram(x1,128,120,128,fs,'yaxis');
title('Stationary Signal'); colorbar;
subplot(2,1,2); spectrogram(x2,128,120,128,fs,'yaxis');
title('Non-Stationary Signal'); colorbar;
