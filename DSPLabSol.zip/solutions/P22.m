% Problem 22: Speech Signal Analysis (Optional Advanced)

% Load audio file (uncomment when you have a .wav file)
% [x, fs] = audioread('speech.wav');
% x = x(:,1);  % take first channel

% Demo with synthetic signal
fs = 8000;
t = 0:1/fs:1;
x = sin(2*pi*440*t) + 0.5*sin(2*pi*880*t);

% STFT
subplot(2,1,1); plot(t,x); title('Signal'); xlabel('t');
subplot(2,1,2); spectrogram(x,256,200,256,fs,'yaxis'); title('Spectrogram');
