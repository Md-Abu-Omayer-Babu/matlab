% Problem 10: Discrete Fourier Transform (DFT)

x = [1 2 3 4];
N = length(x);

% Built-in FFT (normalized)
X_fft = fft(x)/N;

% Manual DFT
X_dft = zeros(1,N);
for k = 0:N-1
    for n = 0:N-1
        X_dft(k+1) = X_dft(k+1) + x(n+1)*exp(-1j*2*pi*k*n/N);
    end
end

disp('FFT (normalized):'); disp(X_fft);
disp('Manual DFT:'); disp(X_dft);
