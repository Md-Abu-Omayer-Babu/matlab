% Problem 17: High-Pass Filter Design

fs = 1000;
t = 0:1/fs:1;

% Signal with DC component
x = sin(2*pi*10*t) + 2;

% FIR high-pass filter
fc = 5;
b = fir1(20, fc/(fs/2), 'high');
y = filter(b, 1, x);

subplot(2,1,1); plot(t,x); title('Original (with DC)'); xlabel('t');
subplot(2,1,2); plot(t,y); title('Filtered (DC removed)'); xlabel('t');
