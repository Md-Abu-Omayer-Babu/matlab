% Problem 19: Frequency Response

fs = 1000;
fc = 100;

% FIR filter
b = fir1(20, fc/(fs/2));
[H, w] = freqz(b, 1, 1024, fs);

subplot(2,1,1); plot(w, 20*log10(abs(H))); title('Magnitude Response'); xlabel('Frequency (Hz)'); ylabel('dB');
subplot(2,1,2); plot(w, angle(H)); title('Phase Response'); xlabel('Frequency (Hz)'); ylabel('Radians');
