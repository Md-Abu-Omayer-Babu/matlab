% Problem 4: Sampling of Analog Signal

t = 0:0.001:1;
f = 5;
x = sin(2*pi*f*t);

fs = [2*f 4*f 1.5*f];  % Nyquist, Above, Below
titles = {'Nyquist (10Hz)', 'Above Nyquist (20Hz)', 'Below Nyquist (7.5Hz)'};

subplot(4,1,1); plot(t,x); title('Original Signal'); xlabel('t');
for i = 1:3
    ts = 0:1/fs(i):1;
    xs = sin(2*pi*f*ts);
    subplot(4,1,i+1); stem(ts,xs); title(titles{i}); xlabel('t');
end
