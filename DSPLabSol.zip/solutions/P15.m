% Problem 15: Random Signal Analysis

N = 1000;
x = randn(1, N);  % white Gaussian noise

m = mean(x);
v = var(x);
sd = std(x);

disp(['Mean: ' num2str(m)]);
disp(['Variance: ' num2str(v)]);
disp(['Std Dev: ' num2str(sd)]);

subplot(2,1,1); plot(x); title('White Gaussian Noise'); xlabel('n');
subplot(2,1,2); hist(x, 50); title('Histogram'); xlabel('Amplitude');
