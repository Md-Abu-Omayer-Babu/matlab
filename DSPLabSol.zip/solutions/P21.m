% Problem 21: Noise Removal Project

fs = 1000;
t = 0:1/fs:1;

% Original signal
x = sin(2*pi*5*t);

% Add noise
noise = 0.5*randn(size(t));
xn = x + noise;

% Filter
fc = 20;
b = fir1(20, fc/(fs/2));
y = filter(b, 1, xn);

% SNR
snr_before = snr(x, noise);
snr_after = snr(x, y - x);

disp(['SNR before filtering: ' num2str(snr_before) ' dB']);
disp(['SNR after filtering: ' num2str(snr_after) ' dB']);

subplot(3,1,1); plot(t,x); title('Original'); xlabel('t');
subplot(3,1,2); plot(t,xn); title('Noisy'); xlabel('t');
subplot(3,1,3); plot(t,y); title('Filtered'); xlabel('t');
