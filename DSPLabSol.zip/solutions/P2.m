% Problem 2: Signal Operations

n = 0:3;
x = [1 2 3 4];

% Time shifting (right by 2)
n_shift = n + 2;
x_shift = x;

% Time scaling (downsample by 2)
n_scale = 0:2:6;
x_scale = x;

% Time reversal
n_rev = -fliplr(n);
x_rev = fliplr(x);

subplot(2,2,1); stem(n,x); title('Original'); xlabel('n');
subplot(2,2,2); stem(n_shift,x_shift); title('Shifted right by 2'); xlabel('n');
subplot(2,2,3); stem(n_scale,x_scale); title('Scaled'); xlabel('n');
subplot(2,2,4); stem(n_rev,x_rev); title('Reversed'); xlabel('n');
