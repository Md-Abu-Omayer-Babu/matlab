% Problem 24: Signal Classification (Basic Intro)

fs = 1000;
t = 0:1/fs:1;

% Generate different signals
x1 = sin(2*pi*10*t);           % sine
x2 = (t >= 0.5);               % step
x3 = randn(1, length(t));      % noise

signals = {x1, x2, x3};
names = {'Sine', 'Step', 'Noise'};

for i = 1:3
    x = signals{i};
    m = mean(x);
    v = var(x);
    disp([names{i} ': Mean=' num2str(m) ', Var=' num2str(v)]);
end

subplot(3,1,1); plot(t,x1); title('Sine'); xlabel('t');
subplot(3,1,2); plot(t,x2); title('Step'); xlabel('t');
subplot(3,1,3); plot(t,x3); title('Noise'); xlabel('t');
