% Problem 20: Filter Comparison

fs = 1000;
fc = 100;

% FIR
b_fir = fir1(20, fc/(fs/2));
[H_fir, w] = freqz(b_fir, 1, 1024, fs);

% IIR (Butterworth)
[b_iir, a_iir] = butter(4, fc/(fs/2));
[H_iir, ~] = freqz(b_iir, a_iir, 1024, fs);

subplot(2,1,1); plot(w, 20*log10(abs(H_fir)), 'b', w, 20*log10(abs(H_iir)), 'r');
legend('FIR','IIR'); title('Magnitude Response'); xlabel('Frequency (Hz)'); ylabel('dB');

subplot(2,1,2); plot(w, angle(H_fir), 'b', w, angle(H_iir), 'r');
legend('FIR','IIR'); title('Phase Response'); xlabel('Frequency (Hz)'); ylabel('Radians');
