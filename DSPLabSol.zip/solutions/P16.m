% Problem 16: Low-Pass Filter Design

fs = 1000;
t = 0:1/fs:1;

% Noisy signal
x = sin(2*pi*5*t) + 0.5*randn(size(t));

% FIR low-pass filter
fc = 20;  % cutoff
b = fir1(20, fc/(fs/2));
y = filter(b, 1, x);

subplot(2,1,1); plot(t,x); title('Noisy Signal'); xlabel('t');
subplot(2,1,2); plot(t,y); title('Filtered Signal (LPF)'); xlabel('t');
