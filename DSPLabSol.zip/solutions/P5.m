% Problem 5: Aliasing Demonstration

t = 0:0.001:1;
f = 10;
x = sin(2*pi*f*t);

fs_alias = 15;  % Below Nyquist (20Hz)
ts = 0:1/fs_alias:1;
x_alias = sin(2*pi*f*ts);

figure;
plot(t,x, 'b'); hold on;
stem(ts,x_alias, 'r');
legend('Original','Aliased');
title('Aliasing Effect (fs=15Hz < Nyquist=20Hz)');
xlabel('t'); ylabel('Amplitude');
