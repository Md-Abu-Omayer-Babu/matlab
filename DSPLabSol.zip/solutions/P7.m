% Problem 7: Uniform Quantizer

t = 0:0.001:1;
x = sin(2*pi*5*t);

L = 8;                      % number of levels
xq = round(x*(L/2-0.5))/(L/2-0.5);  % quantization

subplot(2,1,1); plot(t,x); title('Original Signal'); xlabel('t');
subplot(2,1,2); plot(t,xq); title('Quantized Signal'); xlabel('t');
