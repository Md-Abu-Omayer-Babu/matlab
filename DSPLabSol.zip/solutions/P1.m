% Problem 1: Basic Signal Generation

n = -10:10;

u = (n >= 0);        % step
d = (n == 0);        % impulse
r = n .* (n >= 0);   % ramp
s = sin(n);          % sine
c = cos(n);          % cosine

subplot(3,2,1); stem(n,u); title('Step'); xlabel('n'); ylabel('u[n]');
subplot(3,2,2); stem(n,d); title('Impulse'); xlabel('n'); ylabel('\delta[n]');
subplot(3,2,3); stem(n,r); title('Ramp'); xlabel('n'); ylabel('r[n]');
subplot(3,2,4); stem(n,s); title('Sine'); xlabel('n'); ylabel('sin(n)');
subplot(3,2,5); stem(n,c); title('Cosine'); xlabel('n'); ylabel('cos(n)');
